export type receip = {
    name:string;
    ingre:string;
    ins:string;
    img:string;

}