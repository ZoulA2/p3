import { recipe } from "./recipe";

export type Observer = { render: () => void } & HTMLElement;

export type AppState = {
  recipe:recipe[];
};

export enum RecipeActions {
  "GET" = "GET",
  "ADD" = "ADD",
}

export interface GetRecipe {
  action: RecipeActions.GET;
  payload: recipe[];
}
export interface AddRecipe {
  action: RecipeActions.ADD;
  payload: recipe;
}

export type Actions =  GetRecipe | AddRecipe
