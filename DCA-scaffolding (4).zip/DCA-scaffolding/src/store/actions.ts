import { recipe } from "../types/recipe"
import { Actions, RecipeActions } from "../types/store"
import firebase from "../utils/firebase"




export const Recipes = async (recipe: recipe): Promise <Actions> => {
    await firebase.Recipes(recipe)
    return {
        action: RecipeActions.ADD,
        payload: recipe,
    }
}
export const getrecipes = async (): Promise <Actions> => {
    const recipes = await firebase.GetrecipeFromDB()
    return {
        action: RecipeActions.GET,
        payload: recipes,
    }
}