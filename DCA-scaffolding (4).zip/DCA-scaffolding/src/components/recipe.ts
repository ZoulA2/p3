import { dispatch } from "../store";
import { Recipes } from "../store/actions";
import { recipe } from "../types/recipe";
import styles from  "../card/card.css"

const recipecon: recipe = {
    name : "",
    ingre: "",
    ins: "",
    img: "",

}
export default class recipecard extends HTMLElement {
    constructor(){
        super();
        this.attachShadow({mode: "open"})
    }

    connectedCallback() {
        this.render()
    }

    render() {
        if(this.shadowRoot)this.shadowRoot.innerHTML='';

        const container = this.ownerDocument.createElement("section")
        container.className="cont"

       

        const name = this.ownerDocument.createElement("input")
        name.className = "name"
        name.addEventListener("change", (e: any)=> {
            recipecon.name = e.target.value
        } )

        
        const ingre = this.ownerDocument.createElement("input")
        ingre.className = "name"
        name.addEventListener("change", (e: any)=> {
            recipecon.ingre = e.target.value
        } )


        const ins = this.ownerDocument.createElement("input")
        ins.className = "name"
        name.addEventListener("change", (e: any)=> {
            recipecon.ins = e.target.value
        } )

    
    

        const img = this.ownerDocument.createElement("input")
        img.className = "name"
        name.addEventListener("change", (e: any)=> {
            recipecon.img = e.target.value
        } )
        const btn = this.ownerDocument.createElement("button")
        btn.className = "button"
        btn.textContent ="tengo hambre :(" 
        btn.addEventListener("click", async ()=>{
            console.log(recipecon)
            dispatch(await Recipes(recipecon))
        });


        container.appendChild(name)

        container.appendChild(ingre)
       
        container.appendChild(ins)
        
        container.appendChild(img)

        container.appendChild(btn)

        
        this.shadowRoot?.appendChild(container)

        console.log(recipecon)
        const css = this.ownerDocument.createElement("style");     
        css.innerHTML = styles;
        this.shadowRoot?.appendChild(css);
    }
}

customElements.define('recipe-form', recipecard)